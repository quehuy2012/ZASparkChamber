//
//  TextLabelCollectionViewCell.h
//  ZASparkChamber
//
//  Created by CPU11713 on 6/14/17.
//  Copyright © 2017 CPU11713. All rights reserved.
//

#import "ZASparkCollectionViewCell.h"

@interface TextLabelCollectionViewCell : ZASparkCollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *textLabel;

@end
