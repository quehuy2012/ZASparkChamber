//
//  ZASparkEvent+Internal.h
//  ZASparkChamber
//
//  Created by CPU11713 on 6/14/17.
//  Copyright © 2017 CPU11713. All rights reserved.
//

#import "ZASparkEvent.h"

@interface ZASparkEvent (Internal)

- (BOOL)__send;

@end
